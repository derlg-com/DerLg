import { api } from './api-client'

/**
 * Admin dashboard API client + types (Section 31).
 *
 * ## Backend contract (ASSUMPTION — endpoints do not exist yet)
 *
 * At the time of writing the NestJS backend exposes NO `/v1/admin/*` module.
 * The admin UI is built against the assumed contract below and DEGRADES
 * GRACEFULLY everywhere: list reads use {@link useApiQuery} (which surfaces an
 * error the UI renders as a friendly empty/error state rather than crashing),
 * and mutations surface inline errors. All admin routes are additionally gated
 * server-side-by-role expectations on the backend; the frontend gates by role
 * via `AdminGuard` as a first line of defence.
 *
 * Assumed endpoints (all admin-role guarded server-side):
 *   - `GET    /v1/admin/metrics`                         → {@link AdminMetrics}
 *   - `GET    /v1/admin/bookings?status=`                → {@link AdminBooking}[] (or Paginated)
 *   - `GET    /v1/admin/support-messages`                → {@link AdminSupportMessage}[]
 *   - `POST   /v1/admin/support-messages/:id/reply`      body { reply } → {@link AdminSupportMessage}
 *   - `GET    /v1/admin/reviews`                         → {@link AdminReview}[]
 *   - `PATCH  /v1/admin/reviews/:id`                     body { status } → {@link AdminReview}
 *   - `DELETE /v1/admin/reviews/:id`                     → void
 *   - `GET    /v1/admin/emergency-alerts`                → {@link AdminEmergencyAlert}[]
 */

/** Dashboard headline metrics (Requirement 45.3, 45.8). */
export interface AdminMetrics {
  totalBookings: number
  totalRevenueUsd: number
  totalUsers: number
  /** Optional time series for a simple bar chart: revenue (USD) per recent period. */
  revenueByDay?: Array<{ label: string; valueUsd: number }>
  /** Optional breakdown of bookings by status. */
  bookingsByStatus?: Array<{ status: string; count: number }>
}

/** Zeroed metrics used when the endpoint is unavailable (degrade gracefully). */
export const EMPTY_METRICS: AdminMetrics = {
  totalBookings: 0,
  totalRevenueUsd: 0,
  totalUsers: 0,
  revenueByDay: [],
  bookingsByStatus: [],
}

export interface AdminBooking {
  id: string
  reference: string | null
  userEmail: string | null
  itemName: string | null
  status: string
  totalPriceUsd: number
  createdAt: string
}

export interface AdminSupportMessage {
  id: string
  userEmail: string | null
  subject: string | null
  message: string
  status: 'open' | 'answered' | string
  reply?: string | null
  createdAt: string
}

export type AdminReviewStatus = 'pending' | 'approved' | 'hidden' | string

export interface AdminReview {
  id: string
  authorName: string | null
  subjectName: string | null
  rating: number
  text: string
  status: AdminReviewStatus
  createdAt: string
}

export interface AdminEmergencyAlert {
  id: string
  userEmail: string | null
  bookingReference: string | null
  latitude: number | null
  longitude: number | null
  status: 'active' | 'resolved' | string
  createdAt: string
}

/** Reply to a support message (Requirement 45.5). */
export function replyToSupportMessage(id: string, reply: string) {
  return api.post<AdminSupportMessage>(`/v1/admin/support-messages/${id}/reply`, { reply })
}

/** Moderate a review: approve or hide (Requirement 45.6). */
export function moderateReview(id: string, status: AdminReviewStatus) {
  return api.patch<AdminReview>(`/v1/admin/reviews/${id}`, { status })
}

/** Delete a review (Requirement 45.6). */
export function deleteAdminReview(id: string) {
  return api.delete<void>(`/v1/admin/reviews/${id}`)
}

/** Format a USD amount for compact admin display. */
export function formatUsd(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(Number.isFinite(amount) ? amount : 0)
}
