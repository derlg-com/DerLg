import type { Metadata } from 'next'
import { AdminBookingsView } from '@/components/admin/AdminBookingsView'

export const metadata: Metadata = {
  title: 'Admin · Bookings — DerLg',
  robots: { index: false, follow: false },
}

export default function AdminBookingsPage() {
  return <AdminBookingsView />
}
