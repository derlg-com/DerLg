import type { Metadata } from 'next'
import { AdminAlertsView } from '@/components/admin/AdminAlertsView'

export const metadata: Metadata = {
  title: 'Admin · Emergency Alerts — DerLg',
  robots: { index: false, follow: false },
}

export default function AdminAlertsPage() {
  return <AdminAlertsView />
}
