import type { Metadata } from 'next'
import { AdminSupportView } from '@/components/admin/AdminSupportView'

export const metadata: Metadata = {
  title: 'Admin · Support — DerLg',
  robots: { index: false, follow: false },
}

export default function AdminSupportPage() {
  return <AdminSupportView />
}
