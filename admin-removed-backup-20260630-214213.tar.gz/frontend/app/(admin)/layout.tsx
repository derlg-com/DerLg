import type { ReactNode } from 'react'
import { AdminGuard } from '@/components/admin/AdminGuard'
import { AdminShell } from '@/components/admin/AdminShell'

/**
 * Admin route group layout (Section 31.1). Every route under `(admin)` is
 * gated by {@link AdminGuard} (auth + `role === 'admin'`, non-admins redirected
 * to `/`) and framed by the {@link AdminShell} navigation chrome. This is a
 * standalone surface — it deliberately does NOT render the main app shell
 * (top/bottom nav, chat launcher) so the admin area stays focused.
 */
export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <AdminGuard>
      <AdminShell>{children}</AdminShell>
    </AdminGuard>
  )
}
