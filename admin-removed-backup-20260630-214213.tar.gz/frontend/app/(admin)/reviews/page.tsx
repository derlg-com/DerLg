import type { Metadata } from 'next'
import { AdminReviewsView } from '@/components/admin/AdminReviewsView'

export const metadata: Metadata = {
  title: 'Admin · Reviews — DerLg',
  robots: { index: false, follow: false },
}

export default function AdminReviewsPage() {
  return <AdminReviewsView />
}
