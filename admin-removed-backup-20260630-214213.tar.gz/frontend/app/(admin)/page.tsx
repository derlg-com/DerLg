import { redirect } from 'next/navigation'

/** `/admin` → admin dashboard (Section 31). */
export default function AdminIndexPage() {
  redirect('/admin/dashboard')
}
