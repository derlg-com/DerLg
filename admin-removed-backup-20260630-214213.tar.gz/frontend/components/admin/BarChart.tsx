'use client'

/**
 * Dependency-free bar chart for the admin dashboard (Section 31.2). Renders a
 * simple, accessible CSS bar chart — no charting library — so the admin bundle
 * stays light. Bars scale to the max value; an empty dataset renders nothing.
 */
export interface BarDatum {
  label: string
  value: number
  /** Optional pre-formatted value shown on hover / for screen readers. */
  display?: string
}

export function BarChart({ data, ariaLabel }: { data: BarDatum[]; ariaLabel: string }) {
  if (data.length === 0) return null
  const max = Math.max(...data.map((d) => d.value), 1)

  return (
    <div role="img" aria-label={ariaLabel} className="flex h-40 items-end gap-2">
      {data.map((d, i) => {
        const pct = Math.max(2, Math.round((d.value / max) * 100))
        return (
          <div key={`${d.label}-${i}`} className="flex min-w-0 flex-1 flex-col items-center gap-1">
            <div
              className="w-full rounded-t bg-gradient-brand"
              style={{ height: `${pct}%` }}
              title={`${d.label}: ${d.display ?? d.value}`}
            />
            <span className="w-full truncate text-center text-[10px] text-muted-foreground">
              {d.label}
            </span>
          </div>
        )
      })}
    </div>
  )
}
