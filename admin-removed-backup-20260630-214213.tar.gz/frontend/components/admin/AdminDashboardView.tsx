'use client'

import { CalendarCheck, DollarSign, Users } from 'lucide-react'
import { useApiQuery } from '@/lib/use-api-query'
import { useTranslations } from '@/lib/i18n'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { AdminPageHeading, AdminListSkeleton } from '@/components/admin/AdminSection'
import { BarChart, type BarDatum } from '@/components/admin/BarChart'
import { EMPTY_METRICS, formatUsd, type AdminMetrics } from '@/lib/admin-api'

function MetricCard({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Users
  label: string
  value: string
}) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-4">
        <span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Icon className="h-5 w-5" aria-hidden />
        </span>
        <div className="min-w-0">
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="truncate text-2xl font-bold text-foreground">{value}</p>
        </div>
      </CardContent>
    </Card>
  )
}

/**
 * Admin dashboard (Section 31.2 — Requirements 45.3, 45.8). Shows headline
 * metrics + a lightweight CSS bar chart of recent revenue. Fetches the assumed
 * `GET /v1/admin/metrics`; on error (the endpoint likely does not exist yet) it
 * degrades to zeros/empty rather than crashing.
 */
export function AdminDashboardView() {
  const t = useTranslations('admin')
  const { data, error, isLoading } = useApiQuery<AdminMetrics>('/v1/admin/metrics', { retry: 0 })

  if (isLoading) {
    return (
      <div>
        <AdminPageHeading title={t('dashboard.title')} description={t('dashboard.subtitle')} />
        <AdminListSkeleton rows={3} />
      </div>
    )
  }

  // Degrade gracefully: fall back to zeroed metrics when the endpoint is missing.
  const metrics = data ?? EMPTY_METRICS
  const chartData: BarDatum[] = (metrics.revenueByDay ?? []).map((d) => ({
    label: d.label,
    value: d.valueUsd,
    display: formatUsd(d.valueUsd),
  }))

  return (
    <div className="space-y-6">
      <AdminPageHeading title={t('dashboard.title')} description={t('dashboard.subtitle')} />

      {error ? (
        <p className="rounded-lg border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
          {t('dashboard.unavailable')}
        </p>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <MetricCard
          icon={CalendarCheck}
          label={t('dashboard.bookings')}
          value={String(metrics.totalBookings)}
        />
        <MetricCard
          icon={DollarSign}
          label={t('dashboard.revenue')}
          value={formatUsd(metrics.totalRevenueUsd)}
        />
        <MetricCard icon={Users} label={t('dashboard.users')} value={String(metrics.totalUsers)} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('dashboard.revenueChart')}</CardTitle>
        </CardHeader>
        <CardContent>
          {chartData.length > 0 ? (
            <BarChart data={chartData} ariaLabel={t('dashboard.revenueChart')} />
          ) : (
            <p className="py-8 text-center text-sm text-muted-foreground">
              {t('dashboard.noChartData')}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
