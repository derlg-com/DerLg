'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useTranslations } from '@/lib/i18n'
import { ADMIN_NAV, getActiveAdminHref } from '@/lib/admin-nav'

/**
 * Layout chrome for the admin dashboard (Section 31.1). A minimal, cohesive
 * secondary surface: a header with the admin title and a link back to the main
 * app, plus a horizontal (mobile) / sidebar (desktop) nav highlighting the
 * active section. All labels are i18n-driven (`admin.*`).
 */
export function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const t = useTranslations('admin')
  const active = getActiveAdminHref(pathname)

  return (
    <div className="min-h-dvh bg-background">
      <header className="sticky top-0 z-40 glass border-b border-border/60">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-4">
          <Link
            href="/"
            aria-label={t('backToApp')}
            className="-ml-2 inline-flex items-center gap-1 rounded-lg p-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden />
            <span className="hidden sm:inline">{t('backToApp')}</span>
          </Link>
          <h1 className="font-display text-base font-semibold text-foreground">{t('title')}</h1>
        </div>
      </header>

      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 md:flex-row md:gap-6 md:py-6">
        <nav
          aria-label={t('title')}
          className="-mx-1 flex gap-1 overflow-x-auto md:mx-0 md:w-56 md:flex-col md:overflow-visible"
        >
          {ADMIN_NAV.map((item) => {
            const Icon = item.icon
            const isActive = active === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive ? 'page' : undefined}
                className={cn(
                  'inline-flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                  isActive
                    ? 'bg-primary/10 text-primary'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground',
                )}
              >
                <Icon className="h-4 w-4" aria-hidden />
                {t(`nav.${item.labelKey}`)}
              </Link>
            )
          })}
        </nav>

        <main className="min-w-0 flex-1">{children}</main>
      </div>
    </div>
  )
}
