'use client'

import { useState } from 'react'
import { Star } from 'lucide-react'
import { useApiQuery, invalidateApiQuery } from '@/lib/use-api-query'
import { useTranslations } from '@/lib/i18n'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { EmptyState } from '@/components/ui/empty-state'
import { toast } from '@/components/ui/toast'
import { AdminPageHeading, AdminListSkeleton } from '@/components/admin/AdminSection'
import {
  moderateReview,
  deleteAdminReview,
  type AdminReview,
  type AdminReviewStatus,
} from '@/lib/admin-api'

const REVIEWS_PATH = '/v1/admin/reviews'

function reviewStatusVariant(status: string): 'success' | 'warning' | 'muted' {
  switch (status) {
    case 'approved':
      return 'success'
    case 'hidden':
      return 'muted'
    default:
      return 'warning'
  }
}

function ReviewRow({ review }: { review: AdminReview }) {
  const t = useTranslations('admin')
  const [busy, setBusy] = useState(false)

  async function run(action: () => Promise<unknown>, successKey: string) {
    setBusy(true)
    try {
      await action()
      toast({ title: t(successKey), variant: 'success' })
      // Refresh the moderation list after a successful mutation.
      invalidateApiQuery(REVIEWS_PATH)
    } catch {
      // Degrade gracefully when the (assumed) endpoint is unavailable.
      toast({ title: t('reviews.actionError'), variant: 'error' })
    } finally {
      setBusy(false)
    }
  }

  function moderate(status: AdminReviewStatus, successKey: string) {
    return run(() => moderateReview(review.id, status), successKey)
  }

  return (
    <Card>
      <CardContent className="space-y-3 p-4">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="truncate font-medium text-foreground">
              {review.subjectName ?? t('reviews.unknownSubject')}
            </p>
            <p className="truncate text-sm text-muted-foreground">
              {review.authorName ?? t('reviews.unknownAuthor')} · {'★'.repeat(Math.max(0, Math.min(5, Math.round(review.rating))))}
            </p>
          </div>
          <Badge variant={reviewStatusVariant(review.status)}>
            {t(`reviews.statusLabel.${review.status}`, undefined, 'reviews.statusLabel.pending')}
          </Badge>
        </div>
        <p className="whitespace-pre-wrap text-sm text-foreground">{review.text}</p>
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            variant="outline"
            disabled={busy}
            onClick={() => moderate('approved', 'reviews.approved')}
          >
            {t('reviews.approve')}
          </Button>
          <Button
            size="sm"
            variant="outline"
            disabled={busy}
            onClick={() => moderate('hidden', 'reviews.hidden')}
          >
            {t('reviews.hide')}
          </Button>
          <Button
            size="sm"
            variant="destructive"
            disabled={busy}
            onClick={() => run(() => deleteAdminReview(review.id), 'reviews.deleted')}
          >
            {t('reviews.delete')}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

/**
 * Admin review moderation (Section 31.5 — Requirement 45.6). Lists all reviews
 * and lets admins approve/hide/delete. Fetches the assumed
 * `GET /v1/admin/reviews`; moderation hits `PATCH`/`DELETE /v1/admin/reviews/:id`.
 * Degrades gracefully on error.
 */
export function AdminReviewsView() {
  const t = useTranslations('admin')
  const { data, error, isLoading } = useApiQuery<AdminReview[]>(REVIEWS_PATH, { retry: 0 })
  const reviews = Array.isArray(data) ? data : []

  return (
    <div>
      <AdminPageHeading title={t('reviews.title')} description={t('reviews.subtitle')} />

      {isLoading ? (
        <AdminListSkeleton />
      ) : error || reviews.length === 0 ? (
        <EmptyState
          icon={Star}
          title={t('reviews.emptyTitle')}
          description={error ? t('reviews.unavailable') : t('reviews.emptyDesc')}
        />
      ) : (
        <ul className="space-y-3">
          {reviews.map((r) => (
            <li key={r.id}>
              <ReviewRow review={r} />
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
