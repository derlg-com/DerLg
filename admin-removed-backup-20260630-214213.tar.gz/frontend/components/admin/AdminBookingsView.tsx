'use client'

import { useState } from 'react'
import { CalendarCheck } from 'lucide-react'
import { useApiQuery } from '@/lib/use-api-query'
import { buildQuery } from '@/lib/api-client'
import { useTranslations } from '@/lib/i18n'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select } from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { EmptyState } from '@/components/ui/empty-state'
import { AdminPageHeading, AdminListSkeleton } from '@/components/admin/AdminSection'
import { formatUsd, type AdminBooking } from '@/lib/admin-api'

const STATUS_FILTERS = ['', 'PENDING_PAYMENT', 'CONFIRMED', 'COMPLETED', 'CANCELLED'] as const

function statusVariant(status: string): 'success' | 'warning' | 'destructive' | 'muted' {
  switch (status.toUpperCase()) {
    case 'CONFIRMED':
    case 'COMPLETED':
      return 'success'
    case 'PENDING_PAYMENT':
    case 'HOLD':
      return 'warning'
    case 'CANCELLED':
    case 'EXPIRED':
      return 'destructive'
    default:
      return 'muted'
  }
}

/**
 * Admin booking management (Section 31.3 — Requirement 45.4). Lists all
 * bookings with a status filter and minimal read-only details. Fetches the
 * assumed `GET /v1/admin/bookings?status=`; degrades gracefully to an empty
 * state on error (the endpoint likely does not exist yet).
 */
export function AdminBookingsView() {
  const t = useTranslations('admin')
  const [status, setStatus] = useState<string>('')

  const query = buildQuery({ status: status || undefined })
  const { data, error, isLoading } = useApiQuery<AdminBooking[]>(`/v1/admin/bookings${query}`, {
    retry: 0,
  })

  const bookings = Array.isArray(data) ? data : []

  return (
    <div>
      <AdminPageHeading
        title={t('bookings.title')}
        description={t('bookings.subtitle')}
        action={
          <div className="flex items-center gap-2">
            <Label htmlFor="admin-booking-status" className="sr-only">
              {t('bookings.filterLabel')}
            </Label>
            <Select
              id="admin-booking-status"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="h-9 w-44"
            >
              {STATUS_FILTERS.map((s) => (
                <option key={s || 'all'} value={s}>
                  {s ? t(`bookings.status.${s}`) : t('bookings.status.all')}
                </option>
              ))}
            </Select>
          </div>
        }
      />

      {isLoading ? (
        <AdminListSkeleton />
      ) : error || bookings.length === 0 ? (
        <EmptyState
          icon={CalendarCheck}
          title={t('bookings.emptyTitle')}
          description={error ? t('bookings.unavailable') : t('bookings.emptyDesc')}
        />
      ) : (
        <ul className="space-y-3">
          {bookings.map((b) => (
            <li key={b.id}>
              <Card>
                <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                  <div className="min-w-0">
                    <p className="truncate font-medium text-foreground">
                      {b.itemName ?? t('bookings.unknownItem')}
                    </p>
                    <p className="truncate text-sm text-muted-foreground">
                      {b.reference ? `#${b.reference} · ` : ''}
                      {b.userEmail ?? t('bookings.unknownUser')}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-foreground">
                      {formatUsd(b.totalPriceUsd)}
                    </span>
                    <Badge variant={statusVariant(b.status)}>
                      {t(`bookings.status.${b.status}`, undefined, 'bookings.status.unknown')}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
