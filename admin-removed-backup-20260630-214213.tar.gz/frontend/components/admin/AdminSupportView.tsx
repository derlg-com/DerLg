'use client'

import { useState } from 'react'
import { LifeBuoy } from 'lucide-react'
import { useApiQuery } from '@/lib/use-api-query'
import { useZodForm } from '@/lib/use-zod-form'
import { useTranslations } from '@/lib/i18n'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Spinner } from '@/components/ui/spinner'
import { EmptyState } from '@/components/ui/empty-state'
import { toast } from '@/components/ui/toast'
import { AdminPageHeading, AdminListSkeleton } from '@/components/admin/AdminSection'
import { replyToSupportMessage, type AdminSupportMessage } from '@/lib/admin-api'
import { adminReplySchema, type AdminReplyValues } from '@/schemas/admin-support'

function ReplyForm({ id }: { id: string }) {
  const t = useTranslations('admin')
  const { values, errors, setValue, validate, validateField } = useZodForm<AdminReplyValues>(
    adminReplySchema,
    { reply: '' },
  )
  const [submitting, setSubmitting] = useState(false)
  const [sent, setSent] = useState(false)

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    const data = validate()
    if (!data) return
    setSubmitting(true)
    replyToSupportMessage(id, data.reply)
      .then(() => {
        setSent(true)
        toast({ title: t('support.replySent'), variant: 'success' })
      })
      .catch(() => {
        // Degrade gracefully: the endpoint likely does not exist yet.
        toast({ title: t('support.replyError'), variant: 'error' })
      })
      .finally(() => setSubmitting(false))
  }

  if (sent) {
    return <p className="text-sm text-success">{t('support.replySent')}</p>
  }

  return (
    <form onSubmit={onSubmit} className="space-y-2" noValidate>
      <Label htmlFor={`reply-${id}`} className="sr-only">
        {t('support.replyLabel')}
      </Label>
      <Textarea
        id={`reply-${id}`}
        value={values.reply}
        onChange={(e) => setValue('reply', e.target.value)}
        onBlur={() => validateField('reply')}
        placeholder={t('support.replyPlaceholder')}
        aria-invalid={Boolean(errors.reply)}
        rows={2}
      />
      {errors.reply ? (
        <p className="text-sm text-destructive">{t(`support.errors.${errors.reply}`)}</p>
      ) : null}
      <Button type="submit" size="sm" disabled={submitting}>
        {submitting ? <Spinner size="sm" className="text-primary-foreground" /> : t('support.send')}
      </Button>
    </form>
  )
}

/**
 * Admin support management (Section 31.4 — Requirement 45.5). Lists support
 * messages and lets admins reply. Fetches the assumed
 * `GET /v1/admin/support-messages`; replies POST to
 * `/v1/admin/support-messages/:id/reply`. Degrades gracefully on error.
 */
export function AdminSupportView() {
  const t = useTranslations('admin')
  const { data, error, isLoading } = useApiQuery<AdminSupportMessage[]>(
    '/v1/admin/support-messages',
    { retry: 0 },
  )

  const messages = Array.isArray(data) ? data : []

  return (
    <div>
      <AdminPageHeading title={t('support.title')} description={t('support.subtitle')} />

      {isLoading ? (
        <AdminListSkeleton />
      ) : error || messages.length === 0 ? (
        <EmptyState
          icon={LifeBuoy}
          title={t('support.emptyTitle')}
          description={error ? t('support.unavailable') : t('support.emptyDesc')}
        />
      ) : (
        <ul className="space-y-3">
          {messages.map((m) => (
            <li key={m.id}>
              <Card>
                <CardContent className="space-y-3 p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate font-medium text-foreground">
                        {m.subject ?? t('support.noSubject')}
                      </p>
                      <p className="truncate text-sm text-muted-foreground">
                        {m.userEmail ?? t('support.unknownUser')}
                      </p>
                    </div>
                    <Badge variant={m.status === 'answered' ? 'success' : 'warning'}>
                      {t(`support.statusLabel.${m.status}`, undefined, 'support.statusLabel.open')}
                    </Badge>
                  </div>
                  <p className="whitespace-pre-wrap text-sm text-foreground">{m.message}</p>
                  {m.reply ? (
                    <p className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
                      {t('support.repliedWith')}: {m.reply}
                    </p>
                  ) : (
                    <ReplyForm id={m.id} />
                  )}
                </CardContent>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
