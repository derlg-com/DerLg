'use client'

import { Siren } from 'lucide-react'
import { useApiQuery } from '@/lib/use-api-query'
import { useTranslations } from '@/lib/i18n'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { AdminPageHeading, AdminListSkeleton } from '@/components/admin/AdminSection'
import type { AdminEmergencyAlert } from '@/lib/admin-api'

function hasCoords(a: AdminEmergencyAlert): boolean {
  return typeof a.latitude === 'number' && typeof a.longitude === 'number'
}

/**
 * Admin emergency alert management (Section 31.6 — Requirement 45.7). Lists
 * emergency alerts with their location + status. Fetches the assumed
 * `GET /v1/admin/emergency-alerts`; degrades gracefully on error.
 */
export function AdminAlertsView() {
  const t = useTranslations('admin')
  const { data, error, isLoading } = useApiQuery<AdminEmergencyAlert[]>(
    '/v1/admin/emergency-alerts',
    { retry: 0 },
  )
  const alerts = Array.isArray(data) ? data : []

  return (
    <div>
      <AdminPageHeading title={t('alerts.title')} description={t('alerts.subtitle')} />

      {isLoading ? (
        <AdminListSkeleton />
      ) : error || alerts.length === 0 ? (
        <EmptyState
          icon={Siren}
          title={t('alerts.emptyTitle')}
          description={error ? t('alerts.unavailable') : t('alerts.emptyDesc')}
        />
      ) : (
        <ul className="space-y-3">
          {alerts.map((a) => (
            <li key={a.id}>
              <Card>
                <CardContent className="flex flex-wrap items-center justify-between gap-3 p-4">
                  <div className="min-w-0">
                    <p className="truncate font-medium text-foreground">
                      {a.userEmail ?? t('alerts.unknownUser')}
                    </p>
                    <p className="truncate text-sm text-muted-foreground">
                      {a.bookingReference ? `#${a.bookingReference} · ` : ''}
                      {hasCoords(a)
                        ? `${a.latitude!.toFixed(4)}, ${a.longitude!.toFixed(4)}`
                        : t('alerts.noLocation')}
                    </p>
                  </div>
                  <Badge variant={a.status === 'resolved' ? 'success' : 'destructive'}>
                    {t(`alerts.statusLabel.${a.status}`, undefined, 'alerts.statusLabel.active')}
                  </Badge>
                </CardContent>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
