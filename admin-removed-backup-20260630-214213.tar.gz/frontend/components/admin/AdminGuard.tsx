'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useApiQuery } from '@/lib/use-api-query'
import { useRequireAuth } from '@/hooks/use-auth'
import { Spinner } from '@/components/ui/spinner'
import type { UserProfile } from '@/types/api'

/**
 * Role gate for the admin dashboard (Section 31 — Requirements 45.1, 45.2,
 * 45.9). Extends the {@link useRequireAuth}/`ProtectedRoute` pattern with an
 * additional admin-role check:
 *
 * 1. Require authentication — unauthenticated visitors are redirected to
 *    `/login?returnUrl=…` by {@link useRequireAuth}.
 * 2. Require `role === 'admin'` — the authoritative role comes from
 *    `GET /v1/users/me` (`UserProfile.role`), fetched via {@link useApiQuery}.
 *    Non-admins are redirected to the home page (`/`) (Requirement 45.9).
 *
 * While auth rehydrates or the profile is loading we render `fallback`
 * (a spinner) to avoid flashing admin chrome to a non-admin. If the profile
 * fails to load we treat the user as non-admin and redirect home — admin
 * access fails closed.
 */
export function AdminGuard({
  children,
  fallback,
}: {
  children: React.ReactNode
  fallback?: React.ReactNode
}) {
  const router = useRouter()
  const { isAuthenticated, rehydrated } = useRequireAuth()
  // Only fetch the profile once we know there's an authenticated session.
  const { data: user, isLoading, error } = useApiQuery<UserProfile>(
    rehydrated && isAuthenticated ? '/v1/users/me' : null,
  )

  const isAdmin = user?.role === 'admin'

  useEffect(() => {
    if (!rehydrated || !isAuthenticated) return
    // Wait for the profile to settle before deciding.
    if (isLoading) return
    // Fail closed: a non-admin role OR a failed profile fetch → redirect home.
    if (!isAdmin) {
      router.replace('/')
    }
  }, [rehydrated, isAuthenticated, isLoading, isAdmin, router])

  const spinner = fallback ?? (
    <div className="flex justify-center py-16">
      <Spinner />
    </div>
  )

  // Hold rendering until we can positively confirm an admin session.
  if (!rehydrated || !isAuthenticated) return spinner
  if (isLoading) return spinner
  if (error || !isAdmin) return null

  return <>{children}</>
}
